package net.javaguides.departmentservice.service.impl;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import net.javaguides.departmentservice.DepartmentRepository;
import net.javaguides.departmentservice.dto.DepartmentDto;
import net.javaguides.departmentservice.entity.Department;
import net.javaguides.departmentservice.service.DepartmentService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository departmentRepository;

    private ModelMapper mapper;
    @Override
    public DepartmentDto saveDepartment(DepartmentDto departmentDto) {

        //first covert passed dto to entity before passing to database
        Department department =  mapper.map(departmentDto, Department.class);
        departmentRepository.save(department);


        //For return convert savedDepartment entity to Dto
        DepartmentDto savedDto = mapper.map(department, DepartmentDto.class);

        return savedDto;
    }

    @Override
    public DepartmentDto getDepartmentByCode(String code) {

        Department department = departmentRepository.findByDepartmentCode(code);

        DepartmentDto savedDto = mapper.map(department, DepartmentDto.class);
        return savedDto;
    }
}
