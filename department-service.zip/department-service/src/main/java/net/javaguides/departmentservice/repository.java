package net.javaguides.departmentservice;

public class repository {
}
