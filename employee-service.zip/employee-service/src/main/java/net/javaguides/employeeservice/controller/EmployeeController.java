package net.javaguides.employeeservice.controller;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.javaguides.employeeservice.dto.APIResponseDto;
import net.javaguides.employeeservice.dto.EmployeeDto;
import net.javaguides.employeeservice.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("api/employees")
public class EmployeeController {

    private EmployeeService employeeService;

    //build API to save employee
    @PostMapping
    public ResponseEntity<EmployeeDto> saveEmployee(@RequestBody EmployeeDto employeeDto){
        EmployeeDto savedEmployeed = employeeService.saveEmployee(employeeDto);
        return new ResponseEntity<>(savedEmployeed, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<APIResponseDto> getEmployee(@PathVariable("id") Long employeeID){
        APIResponseDto apiResponseDto = employeeService.getEmployeeById(employeeID);
        return new ResponseEntity<>(apiResponseDto, HttpStatus.OK);
    }

}
